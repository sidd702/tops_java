package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.bean.User;
import com.util.UserUtil;

public class UserDao {
	public static void insertOrUpdateUser(User u) {
		Session session = UserUtil.createSession();
		Transaction tr = session.beginTransaction();// only when there are changes in tbl
		session.saveOrUpdate(u);// if u na obj ma id nahi hoy to save
		tr.commit();
		session.close();
	}

	@SuppressWarnings("unchecked")
	public static List<User> getAllUser() {
		Session session = UserUtil.createSession();
		List<User> list = session.createQuery("from User").list();// Class nu name User
		session.close();
		return list;
	}

	public static User getUser(int uid) {
		Session session = UserUtil.createSession();
		User u = session.get(User.class, uid);
		session.close();
		return u;
	}

	public static void deleteUser(int uid) {
		Session session = UserUtil.createSession();
		Transaction tr = session.beginTransaction();// only when there are changes in tbl
		User u = session.get(User.class, uid);
		session.delete(u);
		tr.commit();
		session.close();
	}
}
