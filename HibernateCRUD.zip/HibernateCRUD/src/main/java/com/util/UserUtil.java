package com.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class UserUtil {
	public static Session createSession() {
		Session session = null;
		SessionFactory sf = new Configuration().addAnnotatedClass(com.bean.User.class).configure()
				.buildSessionFactory();
		session = sf.openSession();
		return session;
	}

}
