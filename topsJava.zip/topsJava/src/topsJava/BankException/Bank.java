package topsJava.BankException;

import java.util.Scanner;

public class Bank {

	public static void main(String[] args) {
		checkingAcct c = new checkingAcct(100, 1000, "Abc");
		int choice;
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("------------------------------");
			System.out.println("1:Dep 2:With 3:chk 4:exit");
			System.out.println("ENter choice");
			choice = sc.nextInt();

			switch (choice) {
				case 1:
					System.out.println("enter amt");
					c.dep(sc.nextDouble());
					break;
				case 2:
					System.out.println("enter with");
					try {
						c.withdraw(sc.nextDouble());
					} catch (InsuffBalException e) {
						System.out.println("Bal Requred" + e.getAmount());
					}
					break;
				case 3:
					c.chkBal();
					break;
				case 4:
					System.exit(0);
					break;
				default:
					System.out.println("galat Dala..exiting..");
					System.exit(0);
					break;
			}

		}
	}

}
