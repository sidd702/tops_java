package com.controller;

import java.io.IOException;

import com.bean.User;
import com.dao.UserDao;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		if (action.equalsIgnoreCase("insert")) {
			User u = new User();
			u.setName(request.getParameter("name"));
			u.setGender(request.getParameter("gender"));
			u.setContact(Long.parseLong(request.getParameter("contact")));
			u.setAddress(request.getParameter("address"));
			UserDao.inserUser(u);

			request.setAttribute("msg", "Data Inserted Successfully.");
			request.getRequestDispatcher("show.jsp").forward(request, response);

		} else if (action.equalsIgnoreCase("edit")) {
			int id = Integer.parseInt(request.getParameter("id"));
			User u = UserDao.getUser(id);
			System.out.println(u.toString());
			request.setAttribute("u", u);
			request.getRequestDispatcher("update.jsp").forward(request, response);
		} else {
			System.out.println("Incorect Action");
		}
	}

}
