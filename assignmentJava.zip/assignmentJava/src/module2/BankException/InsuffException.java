package module2.BankException;

public class InsuffException extends Exception {
	double amt;

	public double getAmt() {
		return amt;
	}

	public void setAmt(double amt) {
		this.amt = amt;
	}

}
