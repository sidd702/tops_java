package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.bean.User;
import com.util.UserUtil;

public class UserDao {
	public static void inserUser(User u) {
		try {
			Connection conn = UserUtil.createConnection();
			String sql = "insert into userdtls(name,gender,address,contact) values (?,?,?,?)";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, u.getName());
			pst.setString(2, u.getGender());
			pst.setString(3, u.getAddress());
			pst.setLong(4, u.getContact());
			pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static List<User> getAllUser() {
		List<User> list = new ArrayList<User>();
		try {
			Connection conn = UserUtil.createConnection();
			String sql = "SELECT * FROM userdtls ";
			PreparedStatement pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				User u = new User();
				u.setId(rs.getInt("id"));
				u.setName(rs.getString("name"));
				u.setGender(rs.getString("gender"));
				u.setContact(rs.getLong("contact"));
				u.setAddress(rs.getString("address"));
				list.add(u);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public static User getUser(int id) {
		User u = null;
		try {
			Connection conn = UserUtil.createConnection();
			String sql = "SELECT * FROM userdtls where id=?;";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			System.out.println(pst.toString());

			u = new User();
			System.out.println(rs.toString());
			u.setId(rs.getInt("id"));
			u.setName(rs.getString("name"));
			u.setGender(rs.getString("gender"));
			u.setContact(rs.getLong("contact"));
			u.setAddress(rs.getString("address"));

		} catch (Exception e) {
			System.err.println("error in User.getUser...........");
			e.printStackTrace();
		}
		return u;
	}
}
