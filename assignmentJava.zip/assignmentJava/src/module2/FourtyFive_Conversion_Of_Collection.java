package module2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

/*
 * Write a Java program to convert a hash set to an array.
• Write a Java program to convert a hash set to a List/Array List
 */
public class FourtyFive_Conversion_Of_Collection {

	@SuppressWarnings("serial")
	public static void main(String[] args) {
		HashSet<Integer> set = new HashSet<Integer>() {
			{
				add(3);
				add(4);
				add(5);
			}
		};
		HashMap<Integer, Character> hm = new HashMap<Integer, Character>() {
			{
				put(1, 'c');
				put(1, 'h');
				put(1, 'i');
			}
		};

		// hs to array
		Integer arr[] = new Integer[set.size()];
		set.toArray(arr);
		System.out.println(Arrays.toString(arr));

		// hs to list
		ArrayList<Integer> alist = new ArrayList<>(set);
		System.out.println(alist);
	}

}
