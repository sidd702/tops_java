package module3;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextField;

public class SwingGUIRegForm implements ActionListener {
	JFrame f;
	JLabel lRegForm, lId, lName, lGen, lAddr, lContact;
	JTextField tfId, tfName, tfAddr, tfContact;
	JRadioButton rbGen;
	JButton btExit, btReg, btDel, btUpdate, btReset;

	public SwingGUIRegForm() {
		f = new JFrame("Registration Form");

		f.setVisible(true);
		f.setSize(1000, 600);
		// f.setLayout(new FlowLayout());
		// f.setLayout(new GridLayout(8, 1));
		f.setLayout(null);
		f.setResizable(false);

		lRegForm = new JLabel("Registration Form");
		lId = new JLabel("Id");
		lName = new JLabel("Name");
		lGen = new JLabel("Gender");
		lAddr = new JLabel("Address");
		lContact = new JLabel("Contact");

		tfId = new JTextField(10);
		tfName = new JTextField(10);
		rbGen = new JRadioButton();
		tfAddr = new JTextField(10);
		tfContact = new JTextField(10);

		// JButton btExit, btReg, btDel, btUpdate, btReset;
		btExit = new JButton("Exit");
		btReg = new JButton("Register");
		btDel = new JButton("Delete");
		btUpdate = new JButton("Update");
		btReset = new JButton("Reset");

		btExit.addActionListener(this);
		btReg.addActionListener(this);
		btDel.addActionListener(this);
		btUpdate.addActionListener(this);
		btReset.addActionListener(this);

		// Add to Frame
		f.add(lRegForm);
		f.add(lId);
		f.add(lName);
		f.add(lGen);
		f.add(lAddr);
		f.add(lContact);

		f.add(tfId);
		f.add(tfName);
		f.add(rbGen);
		f.add(tfAddr);
		f.add(tfContact);

		f.add(btExit);
		f.add(btReg);
		f.add(btDel);
		f.add(btUpdate);
		f.add(btReset);

		lRegForm.setBounds(115, 0, 150, 100);
		lId.setBounds(40, 50, 150, 100);
		lName.setBounds(40, 100, 150, 100);
		lGen.setBounds(40, 150, 150, 100);
		lAddr.setBounds(40, 200, 150, 100);
		lContact.setBounds(40, 250, 150, 100);

		tfId.setBounds(100, 85, 170, 30);
		tfName.setBounds(100, 135, 170, 30);
		rbGen.setBounds(100, 185, 170, 30);
		tfAddr.setBounds(100, 235, 170, 30);
		tfContact.setBounds(100, 285, 170, 30);

		btExit.setBounds(40, 380, 100, 30);
		btReg.setBounds(170, 380, 100, 30);
		btDel.setBounds(40, 430, 100, 30);
		btUpdate.setBounds(170, 430, 100, 30);
		btReset.setBounds(100, 480, 100, 30);

	}

	public JTable createTbl() {
		String[] colName = new String[] { "S No", "Id", "Name", "Gender", "Address", "Contact" };
		Object[][] products = new Object[][] {
				{ "Galleta", "$80" },
				{ "Malta", "$40" },
				{ "Nestea", "$120" },
				{ "Tolta", "$140" }
		};

		JTable table = new JTable(products, colName);
		return table;

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btExit) {
			System.out.println("exit");
			System.exit(0);
		} else if (e.getSource() == btReg) {
			System.out.println("reg");
			try {
				// Load the driver, knows which DB to connect
				Class.forName("com.mysql.jdbc.Driver");
				// establish the connection
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_tts_2", "root", "");

				String sql = "insert into userdftls(name,gender,address,contact) values (?,?,?,?)";

				PreparedStatement pst = conn.prepareStatement(sql);
				pst.setString(1, tfName.getText());
				// pst.setString(2, .getText());
				pst.setString(3, tfAddr.getText());
				pst.setString(4, tfContact.getText());

				pst.executeUpdate();

			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

	}

	public static void main(String[] args) {
		new SwingGUIRegForm();
		new myExitTimer(10000);

	}

}
