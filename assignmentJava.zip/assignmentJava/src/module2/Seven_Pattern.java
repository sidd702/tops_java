package module2;

import java.util.Scanner;

/*• Write a program in Java to make such a pattern like right angle triangle with number
increased by 1 The pattern like:
1
2 3
4 5 6
7 8 9 10*/
public class Seven_Pattern {

	public static void main(String[] args) {
		int i, h, j, count = 1;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter :");
		h = sc.nextInt();

		for (i = 1; i <= h; i++) {
			for (j = 1; j <= i; j++) {
				System.out.print(count++ + " ");
			}
			System.out.println();
		}
	}

}
