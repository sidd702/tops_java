package com.servlet;

import java.io.IOException;

import com.bean.User;
import com.dao.UserDao;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/UserController")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");

		if (action.equalsIgnoreCase("Register")) {
			User u = new User();
			u.setFname(request.getParameter("fname"));
			u.setLname(request.getParameter("lname"));
			u.setEmail(request.getParameter("email"));
			u.setGender(request.getParameter("gender"));
			u.setPassword(request.getParameter("password"));
			u.setContact_no(Long.parseLong(request.getParameter("contact")));

			UserDao.insertOrUpdateUser(u);
			response.sendRedirect("index.jsp");

		} else if (action.equalsIgnoreCase("edit")) {
			int uid = Integer.parseInt(request.getParameter("uid"));
			User u = UserDao.getUser(uid);
			request.setAttribute("u", u);
			request.getRequestDispatcher("edit.jsp").forward(request, response);
		} else if (action.equalsIgnoreCase("Update Registration")) {
			User u = new User();
			u.setUid(Integer.parseInt(request.getParameter("uid")));
			u.setFname(request.getParameter("fname"));
			u.setLname(request.getParameter("lname"));
			u.setEmail(request.getParameter("email"));
			u.setGender(request.getParameter("gender"));
			u.setPassword(request.getParameter("password"));
			u.setContact_no(Long.parseLong(request.getParameter("contact")));

			UserDao.insertOrUpdateUser(u);
			response.sendRedirect("index.jsp");

		} else if (action.equalsIgnoreCase("Delete")) {
			int uid = Integer.parseInt(request.getParameter("uid"));
			UserDao.deleteUser(uid);
			response.sendRedirect("index.jsp");
		}
	}

}
