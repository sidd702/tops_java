package module2;

import java.util.Scanner;

/*Write a Java program that reads a positive integer and count the number of digits the
number*/
public class Eight_CountDigitInNum {

	public static void main(String[] args) {
		int n, c;
		Scanner sc = new Scanner(System.in);
		System.out.println("Input an integer number less than ten billion :");
		n = sc.nextInt();

		System.out.println("Number of digits in the number " + Integer.toString(n).length());

	}

}
