package module2;

/*
 * Write a program to print the area and perimeter of a triangle having sides of 3, 4 and
5 units by creating a class named 'Triangle' without any parameter in its constructor
 */
class Triangle {
	public Triangle() {
		System.out.println("Area " + (0.5 * 3 * 4));
		System.out.println("Perimeter " + (3 + 4 + 5));
	}
}

public class Twenty_Six_Triangle_Peri {
	public static void main(String[] args) {
		Triangle t = new Triangle();
	}
}
