package com.servlet;

import java.io.IOException;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class MyServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletConfig config;
	ServletContext context;
	String email, driver;

	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init");
		this.config = config;
		this.context = context;
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("doGet");
		email = config.getInitParameter("email");
		System.out.println("email: " + email);
		email = config.getInitParameter("driver");
		System.out.println("driver: " + driver);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("doPost");
	}

	@Override
	public void destroy() {
		System.out.println("destroy");
	}
}
