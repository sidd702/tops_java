package module2;

/*Create a class named 'Rectangle' with two data members 'length' and 'breadth' and
two methods to print the area and perimeter of the rectangle respectively. Its
constructor having parameters for length and breadth is used to initialize the length
and breadth of the rectangle. Let class 'Square' inherit the 'Rectangle' class with its
constructor having a parameter for its side (suppose s) calling the constructor of its
parent class as 'super (s, s)'. Print the area and perimeter of a rectangle and a square*/

class Rectangle {
	float l, w;

	public Rectangle(float l, float w) {
		this.l = l;
		this.w = w;
	}

	void areaR() {
		if (l == w) {
			System.out.println("Square area: " + l * w);
		} else {
			System.out.println("Rectangle area: " + l * w);
		}
	}

	void perimeterR() {
		if (l == w) {
			System.out.println("Square perimeter: " + (2 * l + 2 * w));
		} else {
			System.out.println("Rectangle perimeter: " + (2 * l + 2 * w));
		}
	}
}

class Square extends Rectangle {
	public Square(Long s) {
		super(s, s);
	}
}

public class Twenty_Five_Rectangle_Single_Inheri {
	public static void main(String[] args) {
		Square s = new Square(5l);
		Rectangle r = new Rectangle(5, 10);
		s.areaR();
		s.perimeterR();
		r.areaR();
		r.perimeterR();

	}

}
