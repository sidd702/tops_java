package swingGUIDemo;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class SwingGUIDemo {
	JFrame f;
	JLabel lRegForm, lId, lName, lGen, lAddr, lContact;
	JTextField tfId, tfName, tfAddr, tfContact;
	JRadioButton rbGen;
	JButton btExit, btReg, btDel, btUpdate, btReset;

	public SwingGUIDemo() {
		f = new JFrame("My Swing Demo");
		f.setVisible(true);
		f.setSize(1000, 600);
		// f.setLayout(new FlowLayout());
		// f.setLayout(new GridLayout(8, 1));
		f.setLayout(null);
		f.setResizable(false);

		lRegForm = new JLabel("Registration Form");
		lId = new JLabel("Id");
		lName = new JLabel("Name");
		lGen = new JLabel("Gender");
		lAddr = new JLabel("Address");
		lContact = new JLabel("Contact");

		tfId = new JTextField(10);
		tfName = new JTextField(10);
		rbGen = new JRadioButton();
		tfAddr = new JTextField(10);
		tfContact = new JTextField(10);

		// JButton btExit, btReg, btDel, btUpdate, btReset;
		btExit = new JButton("Exit");
		btReg = new JButton("Register");
		btDel = new JButton("Delete");
		btUpdate = new JButton("Update");
		btReset = new JButton("Reset");

		// Add to Frame
		f.add(lRegForm);
		f.add(lId);
		f.add(lName);
		f.add(lGen);
		f.add(lAddr);
		f.add(lContact);

		f.add(tfId);
		f.add(tfName);
		f.add(rbGen);
		f.add(tfAddr);
		f.add(tfContact);

		f.add(btExit);
		f.add(btReg);
		f.add(btDel);
		f.add(btUpdate);
		f.add(btReset);

		lRegForm.setBounds(50, 50, 50, 50);
	}

	public static void main(String[] args) {
		new SwingGUIDemo();
		new myExitTimer(5000);

	}

}
