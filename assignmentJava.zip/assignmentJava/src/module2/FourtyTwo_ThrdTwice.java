package module2;

/*
 * W.A.J.P to start the same Thread twice by calling start () method twice. Test
ThreadTwice1 t1=new TestThreadTwice1(); t1.start (); t1.start 
 */
class TestThreadTwice1 implements Runnable {
	Thread t;

	public TestThreadTwice1(String name) {
		t = new Thread(this, name);
		t.start();
		// t.start();can not do this as per java
	}

	public void run() {
		System.out.println(t + "is running...");
	}
}

public class FourtyTwo_ThrdTwice {

	public static void main(String[] args) {
		TestThreadTwice1 t = new TestThreadTwice1("myThrd");
	}

}
