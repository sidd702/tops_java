package com.service;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmpServices {

	public static void sendEmail(String email, int otp)
	{
		final String username = "siddshah702@gmail.com";// sender email
		final String password = "qaoh gzqm jibp ojoq ";// sender password

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication()
					{
						return new PasswordAuthentication(username, password);
					}
				});
		try
		{
			Message msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(username));
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email));// to mail addr
			msg.setSubject("Employee Mgmt System OTP For Forgot Password");
			msg.setText("Dear User, \n\n Your OTP For Forgot Password is " + otp);

			Transport.send(msg);

			System.out.println("\n\nEmail : " + msg + "\n\n");
		} catch (MessagingException e)
		{
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

}
