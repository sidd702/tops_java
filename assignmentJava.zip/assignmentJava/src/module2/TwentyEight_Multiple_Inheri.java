package module2;

/*
 * Create an abstract class 'Parent' with a method 'message'. It has two subclasses each
having a method with the same name 'message' that prints "This is first subclass"
and "This is second subclass" respectively. Call the methods 'message' by creating
an object for each subclass
 */
class Parent1 {
	void msg() {
		System.out.println("Parent CLass");
	}
}

class sub1 extends Parent1 {
	void msg() {
		System.out.println("Sub1 CLass");
	}
}

class sub2 extends Parent1 {
	void msg() {
		System.out.println("Sub2 CLass");
	}
}

public class TwentyEight_Multiple_Inheri {

	public static void main(String[] args) {
		sub1 s1 = new sub1();
		sub2 s2 = new sub2();
		s1.msg();
		s2.msg();
	}

}
