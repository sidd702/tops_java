package module2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/*
 * Write a Java program to create a new array list, add some colors (string) and print out
the collection
Write a Java program to iterate through all elements in an array list.
Write a Java program to insert an element into the array list at the first position.
Write a Java program to retrieve an element (at a specified index) from a given array
list.
Write a Java program to update specific array element by given element.
Write a Java program to remove the third element from an array list.
Write a Java program to search an element in an array list.
Write a Java program to sort a given array list.
Write a Java program to copy one array list into another.
Write a Java program to shuffle elements in an array list

Write a Java program to extract a portion of an array list.
Write a Java program to compare two array lists.
Write a Java program of swap two elements in an array list.
Write a Java program to join two array lists.
*/
public class FourtyFour_ArrayListOP {
	public static void main(String[] args) {
		ArrayList<String> s = new ArrayList<String>();
		s.add("Red");
		s.add("Blue");
		s.add("Green");
		s.add("Yellow");

		for (String t : s) {
			System.out.print(t + " ");
		}

		s.add(0, "White");

		System.out.println("\n3rd index: " + s.get(3));

		s.set(0, "RedUpdated");

		s.remove(2);

		for (String string : s) {
			if (string.equals("Yellow")) {
				System.out.println("Yellow is present");
				break;
			} else {
				continue;
			}
		}

		System.out.println(s);

		System.out.println("----------------------------------------------------");

		/*
		 * Write a Java program to sort a given array list.
		 * Write a Java program to copy one array list into another.
		 * Write a Java program to shuffle elements in an array list
		 */

		ArrayList<Integer> arr = new ArrayList<Integer>() {
			{
				add(1);
				add(45);
				add(5);
				add(44);
				add(88);
				add(145);
				add(100);
				add(156);
				add(4);

			}
		};
		System.out.println("Before" + arr);
		Collections.sort(arr);
		System.out.println("After   asc sort" + arr);
		Collections.sort(arr, Collections.reverseOrder());
		System.out.println("After dsc sort" + arr);
		Collections.shuffle(arr);
		System.out.println("shuffle list " + arr);

		System.out.println("----------------------------------------------------");
		/*
		 * Write a Java program to extract a portion of an array list.
		 * Write a Java program to compare two array lists.
		 * Write a Java program of swap two elements in an array list.
		 * Write a Java program to join two array lists.
		 */

		ArrayList<Character> ch = new ArrayList<Character>() {
			{
				add('a');
				add('s');
				add('d');
				add('r');
				add('f');
				add('h');
				add('t');
				add('g');

				add('g');
				add('y');
				add('f');
				add('k');
				add('l');
				add(';');
				add('p');

			}
		};

		List<Character> sub = ch.subList(2, 5);
		System.out.println(sub);
		ArrayList<Character> copyList = new ArrayList<Character>(ch);

		Comparator<List<Character>> c = new Comparator<List<Character>>() {

			@Override
			public int compare(List<Character> o1, List<Character> o2) {
				if (o1.equals(o2)) {
					return 1;
				} else {
					return 0;
				}
			}
		};

		if (c.compare(ch, sub) == 1) {
			System.out.println("ch and sub Two ArrayList are Same");
		} else {
			System.out.println("ch and sub Two ArrayList are NOT Same");
		}
		if (c.compare(ch, copyList) == 1) {
			System.out.println("ch, copyList Two ArrayList are Same");
		} else {
			System.out.println("ch, copyList Two ArrayList are NOT Same");
		}

		System.out.println("\n\n\n----------------join two list");

		// join two list
		ArrayList<Integer> l1 = new ArrayList<Integer>() {
			{
				add(1);
				add(2);
			}
		};
		ArrayList<Integer> l2 = new ArrayList<Integer>() {
			{
				add(10);
				add(20);
			}
		};

		l1.addAll(l2);
		System.out.println("l1 " + l1);

	}
}
