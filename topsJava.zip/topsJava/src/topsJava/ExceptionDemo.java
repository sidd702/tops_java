package topsJava;

import java.util.Scanner;

public class ExceptionDemo {
	public static void main(String[] args) {
		System.out.println("Start");
		int a, b, c;
		Scanner sc = new Scanner(System.in);

		try {
			System.out.println("Enter a:");
			a = sc.nextInt();
			System.out.println("Enter b:");
			b = sc.nextInt();

			c = a / b;
			System.out.println("c: " + c);
		} catch (Exception e) {
			System.out.println("Exception" + e);
		}
		System.out.println("End Code");
	}
}
