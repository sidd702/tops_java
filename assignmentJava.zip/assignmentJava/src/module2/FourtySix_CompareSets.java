package module2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

/*
 * Write a Java program to compare two sets and retain elements which are same on
both sets.
 */
public class FourtySix_CompareSets {
	@SuppressWarnings("serial")
	public static void main(String[] args) {

		ArrayList<Integer> lst = new ArrayList<Integer>();
		HashSet<Integer> set1 = new HashSet<Integer>() {
			{
				add(3);
				add(4);
				add(55);
			}
		};
		HashSet<Integer> set2 = new HashSet<Integer>() {
			{
				add(5);
				add(67);
				add(55);
			}
		};

		Iterator<Integer> itr1 = set1.iterator();
		Iterator<Integer> itr2 = set2.iterator();
		while (itr1.hasNext() && itr2.hasNext()) {
			int i1 = itr1.next();
			int i2 = itr2.next();
			if (i1 == i2) {
				lst.add(i1);
			}
		}
		System.out.println("same ele: " + lst);
	}
}
