package module2;

import java.util.Scanner;

/*
 * Take two numbers from the user and perform the division operation and handle
Arithmetic Exception. O/P- Enter two numbers: 10 0
Exception in thread main java.lang.ArithmeticException:/ by zero
 */
public class ThirtySix_ArithException {

	public static void main(String[] args) {
		int n, m;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter n: ");
		n = sc.nextInt();
		System.out.println("Enter m: ");
		m = sc.nextInt();

		try {
			int i = n / m;
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
