package com.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class UserUtil {

	public static Connection createConnection() {
		Connection conn = null;

		try {
			// Load the driver, knows which DB to connect
			Class.forName("com.mysql.jdbc.Driver");
			// establish the connection
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/java_tts_2", "root", "");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return conn;
	}

}
