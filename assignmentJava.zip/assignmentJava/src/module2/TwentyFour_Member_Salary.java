package module2;

/*
 * Create a class named 'Member' having the following members:
1. Data members
2. Name
3. Age
4. Phone number
5. Address
6. Salary
It also has a method named 'printSalary' which prints the salary of the members
 */
class Member {
	String name;
	Integer age;
	Integer mobile;
	String add;
	Long salary;

	public Member(String name, Integer age, Integer mobile, String add, Long salary) {
		this.name = name;
		this.age = age;
		this.mobile = mobile;
		this.add = add;
		this.salary = salary;
	}

	public void printSalary() {
		System.out.println(salary);
	}
}

public class TwentyFour_Member_Salary {

	public static void main(String[] args) {
		Member e1 = new Member("Sid", 25, 9564545, "Bopal", 35000L);
		e1.printSalary();
	}

}
