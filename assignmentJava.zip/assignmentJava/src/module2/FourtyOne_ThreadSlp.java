package module2;

/*
 * W.A.J.P to create 2 threads and execute that threads by providing sleep time as
2000ms and check the execution
 */
class Thrd1 extends Thread {
	Thread t;

	public Thrd1() {
		t = new Thread(this, "Thrd1");
		t.start();
	}

	public void run() {

		System.out.println(t + " Thrd1 Running...");
		try {
			t.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

class Thrd2 implements Runnable {
	Thread t;

	public Thrd2() {
		t = new Thread(this, "Thrd2");
		t.start();
	}

	@Override
	public void run() {
		System.out.println(t + " Thrd2 Running...");
		try {
			t.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

public class FourtyOne_ThreadSlp {

	public static void main(String[] args) {
		Thrd1 t1 = new Thrd1();
		Thrd2 t2 = new Thrd2();
	}

}
