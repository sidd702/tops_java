package module2;

//W.A.J.P to concatenate a given string to the end of another string.
public class Fifteen_ConcanateString {

	public static void main(String[] args) {
		String s1 = "abc";
		String s2 = "def";

		System.out.println(s1.concat(s2));
	}

}
