package module2;

/*Create a class to print the area of a square and a rectangle. The class has two methods
with the same name but different number of parameters. The method for printing
area of a rectangle has two parameters which are length and breadth respectively
while the other method for printing area of square has one parameter which is side
of square*/
class calArea {
	void area(int l) {
		System.out.println("Sqr area: " + l * l);
	}

	void area(int l, int h) {
		System.out.println("Tri area: " + 0.5 * l * h);
	}
}

public class TwentyTwo_CalArea_Sqr_Tri {

	public static void main(String[] args) {
		calArea c = new calArea();
		c.area(5);
		c.area(5, 4);
	}

}
