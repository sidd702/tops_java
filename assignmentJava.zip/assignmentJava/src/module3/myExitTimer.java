package module3;

import java.util.Timer;
import java.util.TimerTask;

public class myExitTimer {
	public myExitTimer(int time) {
		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				System.exit(0);
			}
		};
		Timer t = new Timer();
		t.schedule(task, time);
	}
}
