package topsJava;

public class AbstrctClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
