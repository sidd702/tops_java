package module2;

import java.util.Date;

//Write a Java program to display the system time.
public class Twleve_SysTime {

	public static void main(String[] args) {
		System.out.println(new Date());
	}

}
