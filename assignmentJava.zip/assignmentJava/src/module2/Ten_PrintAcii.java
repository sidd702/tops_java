package module2;

import java.util.Scanner;

/*Write a Java program to print the ASCII value of a given character*/
public class Ten_PrintAcii {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter char:");
		System.out.println((int) sc.next().charAt(0));
	}

}
