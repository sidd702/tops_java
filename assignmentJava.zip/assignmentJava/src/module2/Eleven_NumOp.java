package module2;

import java.util.Scanner;

/*Write a Java program that accepts an integer (n) and computes the value of
n+nn+nnn. Input number: 5
5 + 55 + 555*/
public class Eleven_NumOp {

	public static void main(String[] args) {
		int dgt, sum = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter digit: ");
		dgt = sc.nextInt();

		sum = dgt + (dgt * 10 + dgt) + (dgt + dgt * 10 + dgt * 100);

		System.out.println("sum: " + sum);
	}

}
