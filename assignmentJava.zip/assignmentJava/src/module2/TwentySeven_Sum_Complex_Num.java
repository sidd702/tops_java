package module2;

/*IGNORE
 * Print the sum, difference and product of two complex numbers by creating a class
named 'Complex' with separate methods for each operation whose real and
imaginary parts are entered by user
 */

class Complex {
}

public class TwentySeven_Sum_Complex_Num {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
