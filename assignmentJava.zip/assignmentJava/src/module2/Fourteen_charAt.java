package module2;

import java.util.Scanner;

//W.A.J.P to get the character at the given index within the String. Original String =
//Tops Technologies! The character at position 0 is T, The character at position 10 is o

public class Fourteen_charAt {

	public static void main(String[] args) {
		String s = "Tops Technologies!";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter :");
		System.out.println(s.charAt(sc.nextInt()));
		sc.close();
	}

}
