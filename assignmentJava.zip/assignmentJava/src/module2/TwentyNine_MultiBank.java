package module2;

/*
 * Create an abstract class 'Bank' with an abstract method 'getBalance'. $100, $150 and
$200 are deposited in banks A, B and C respectively. 'BankA', 'BankB' and 'BankC'are subclasses of class 'Bank', each having a method named 'getBalance'. Call this
method by creating an object of each of the three classes.
 */
abstract class Bank {
	abstract Long getBalance();
}

class Bank1 extends Bank {
	Long bal;

	public Bank1(Long bal) {
		this.bal = bal;
	}

	@Override
	Long getBalance() {
		return bal;
	}
}

class Bank2 extends Bank {
	Long bal;

	public Bank2(Long bal) {
		this.bal = bal;
	}

	@Override
	Long getBalance() {
		return bal;
	}
}

class Bank3 extends Bank {
	Long bal;

	public Bank3(Long bal) {
		this.bal = bal;
	}

	@Override
	Long getBalance() {
		return bal;
	}
}

public class TwentyNine_MultiBank {

	public static void main(String[] args) {
		Bank1 b1 = new Bank1(50l);
		Bank2 b2 = new Bank2(60l);
		Bank3 b3 = new Bank3(70l);
		System.out.println(b1.getBalance());
		System.out.println(b2.getBalance());
		System.out.println(b3.getBalance());
	}

}
