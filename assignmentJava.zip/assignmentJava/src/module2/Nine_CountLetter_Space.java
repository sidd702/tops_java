package module2;

import java.util.Scanner;

/*Write a Java program to count the letters, spaces, numbers and other characters of
an input string*/
public class Nine_CountLetter_Space {
	public static void main(String[] args) {
		String s;
		int i, spcnt = 0, ltrCnt = 0, numCnt = 0, ocCnt = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter :");
		s = sc.nextLine();

		for (i = 0; i < s.length(); i++) {
			System.out.println(s.charAt(i));
			if (s.charAt(i) == ' ') {
				spcnt++;
			} else if (s.charAt(i) >= 'A' && s.charAt(i) <= 'z') {
				ltrCnt++;
			} else if (s.charAt(i) >= 0 && s.charAt(i) <= 9) {
				numCnt++;
			} else {
				ocCnt++;
			}
		}

		// System.out.println(s);
		System.out.println("spcnt " + spcnt);
		System.out.println("ltrCnt " + ltrCnt);
		System.out.println("numCnt " + numCnt);
		System.out.println("ocCnt " + ocCnt);

	}
}
