package module2.BankException;

import java.util.Scanner;

/*
 * W.A.J.P to create a custom exception if Customer withdraw amount which is greater
than account balance then program will show custom exception otherwise amount
will deduct from account balance. Account balance is: 2000 Enter withdraw amount:
2500
Sorry, insufficient balance, you need more 500 Rs. To perform this transaction.
• 
 */
class Bank {
	double amt;

	public Bank(double amt) {
		this.amt = amt;
	}

	double chkBal() {
		return amt;
	}

	void deposit(double a) {
		amt += a;
	}

	void withdraw(double a) {
		if (a > amt) {
			System.out.println(
					"Sorry, insufficient balance, you need more " + (a - amt)
							+ " Rs.To perform this transaction. Exiting..");
			System.exit(0);
		} else {
			amt -= a;
		}
	}
}

public class ThirtyNine_Bank_Insuff_Exception {

	public static void main(String[] args) {
		Bank acct = new Bank(5000);
		int choice;
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("------------------------------");
			System.out.println("1:Dep 2:With 3:chk 4:exit");
			System.out.println("ENter choice");
			choice = sc.nextInt();

			if (choice == 1) {
				System.out.println("enter amt");
				acct.deposit(sc.nextDouble());
			} else if (choice == 2) {
				System.out.println("enter amt");
				acct.withdraw(sc.nextDouble());
			} else if (choice == 3) {
				System.out.println("Your bal is " + acct.chkBal());
			} else if (choice == 4) {
				System.exit(0);
			} else {
				System.out.println("Invalid Choice");
				continue;
			}
		}
	}
}
