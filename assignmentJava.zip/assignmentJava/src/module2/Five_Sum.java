package module2;

import java.util.Scanner;

//Write a program in Java to input 5 numbers from keyboard and find their sum and
//average using for loop
public class Five_Sum {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[] a = new int[5];
		int i, sum = 0;
		for (i = 0; i < 5; i++) {
			System.out.println(i + " Enter :");
			a[i] = sc.nextInt();
		}
		for (i = 0; i < 5; i++) {
			sum += a[i];
		}

		System.out.println("Sum is " + sum + " Avg is " + sum / 5);
	}

}
