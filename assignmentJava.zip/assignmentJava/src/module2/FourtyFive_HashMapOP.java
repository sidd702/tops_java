package module2;

import java.util.HashMap;

/*
 * Write a Java program to iterate through all elements in a hash list.
• Write a Java program to get the number of elements in a hash set.
• Write a Java program to associate the specified value with the specified key in a
Hash Map.
• Write a Java program to count the number of key-value (size) mappings in a map
 */
public class FourtyFive_HashMapOP {

	@SuppressWarnings("serial")
	public static void main(String[] args) {
		HashMap<Integer, String> hm = new HashMap<Integer, String>() {
			{
				put(1, "sid");
				put(2, "Acb");
				put(3, "dfg");
				put(4, "sf");
				put(5, "sff");
				put(8, "vvv");
			}
		};

		hm.forEach((key, val) -> System.out.println(key + " = " + val));

		System.out.println("HM size is " + hm.size());
	}

}
