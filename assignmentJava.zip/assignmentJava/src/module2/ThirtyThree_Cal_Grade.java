package module2;

import java.util.Scanner;

/*
 * Write a program which will ask the user to enter his/her
marks (out of 100). Define a method that will display grades according to the marks
entered as below:
Marks Grade
91-100 AA
81-90 AB
71-80 BB
61-70 BC
51-60 CD
41-50 DD
Fail
 */
public class ThirtyThree_Cal_Grade {

	public static void main(String[] args) {
		int marks;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Marks");
		marks = sc.nextInt();

		if (marks < 101 && marks >= 91) {
			System.out.println("Grade: AA");
		}
		if (marks < 91 && marks >= 81) {
			System.out.println("Grade: AB");
		}
		if (marks < 81 && marks >= 71) {
			System.out.println("Grade: BB");
		}
		if (marks < 71 && marks >= 61) {
			System.out.println("Grade: BC");
		}
		if (marks < 61 && marks >= 51) {
			System.out.println("Grade: CC");
		}
		if (marks < 51 && marks >= 41) {
			System.out.println("Grade: DDs");
		} else if (marks <= 40) {
			System.out.println("Grade: Fail");
		}

	}

}
