package module2;

//Write a program in Java to display the first 10 natural numbers
//using while loop
public class FourNaturalNum {

	public static void main(String[] args) {
		int i = 1;
		while (i < 11) {
			System.out.println(i++);
		}
	}

}
