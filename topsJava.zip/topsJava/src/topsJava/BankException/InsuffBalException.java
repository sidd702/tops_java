package topsJava.BankException;

public class InsuffBalException extends Exception {
	double amount;

	public InsuffBalException(double amount) {
		this.amount = amount;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

}
