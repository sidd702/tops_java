package module2;

/*W.A.J.P to check whether a given string ends with the contents of another string.
"Java Exercises" ends with "se"? False "Java Exercise" ends with "se"? True*/
public class Sixteen_String_EndsWith {

	public static void main(String[] args) {
		String s1 = "Java Exercises";
		String s2 = "se";

		System.out.println(s1.endsWith(s2));

	}

}
