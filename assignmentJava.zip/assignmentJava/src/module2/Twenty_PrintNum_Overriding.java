package module2;

/*Create a class named 'Print Number' to print various numbers of different data types
by creating different methods with the same name 'printn' having a parameter for
each data type.*/
class Print_Num {
	void printn(int n) {
		System.out.println(n);
	}

	void printn(long n) {
		System.out.println(n);
	}

	void printn(double n) {
		System.out.println(n);
	}

	void printn(float n) {
		System.out.println(n);
	}
}

public class Twenty_PrintNum_Overriding {

	public static void main(String[] args) {
		Print_Num o = new Print_Num();
		o.printn(1);
		o.printn(14334343);
		o.printn(23.34);
		o.printn(43343);
	}

}
