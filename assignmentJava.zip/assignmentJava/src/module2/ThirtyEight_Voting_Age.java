package module2;

import java.util.Scanner;

/*
 * W.A.J.P to create the validate method that takes integer value as a parameter. If the
age is less than 18, then throw an Arithmetic Exception otherwise print a message
welcome to vote
 */
public class ThirtyEight_Voting_Age {

	public static void main(String[] args) {
		int a;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter age: ");
		a = sc.nextInt();

		if (a < 18) {
			throw new ArithmeticException("Not Valid");
		} else {
			System.out.println("Welcome to Vote");
		}
	}

}
