package module2;

/*
 * W.A.J. P to implement the above program (pro.no-B27) using nesting of try-catch
block. try {
try
{//code}
catch (Exception e)
{//code}
catch (Exception e)
{//code}
 */
public class ThiertySeven_MultipleCatch {

	public static void main(String[] args) {
		int[] a = { 1, 2, 3, 4, 5 };
		int i;
		try {
			// i = a[0] / 0;
			i = 55 / a[4];

			i = a[7];
		} catch (ArithmeticException e) {
			System.out.println(e);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}

	}

}
