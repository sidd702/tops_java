package module2;

import java.util.Scanner;

public class One {

	public static void main(String[] args) {
		// Write a Java program to Take three numbers from the user and print
		// the
		// greatest
		// number
		int x, y, z;
		Scanner sc = new Scanner(System.in);
		System.out.println("1: ");
		x = sc.nextInt();
		System.out.println("2: ");
		y = sc.nextInt();
		System.out.println("3: ");
		z = sc.nextInt();

		if (x >= y) {
			if (x >= z)
				System.out.println(x);
			else
				System.out.println(z);
		} else {
			if (y >= z)
				System.out.println(y);
			else
				System.out.println(z);
		}
	}

}
