package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet2
 */
public class MyServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ServletConfig config;
	ServletContext context;
	String email, driver;

	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init");
		this.config = config;
		this.context = config.getServletContext();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("doGet");
		email = config.getInitParameter("email");
		System.out.println("email: " + email);
		driver = context.getInitParameter("driver");
		System.out.println("driver: " + driver);

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.print("<html><body>");
		out.print("<h2>Welcome to Servlet</h2>");
		out.print("<h3>email : " + email + "</h3>");
		out.print("<h3>driver : " + driver + "</h3>");
		out.print("</body></html>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("doPost");
	}

	@Override
	public void destroy() {
		System.out.println("destroy");
	}
}
