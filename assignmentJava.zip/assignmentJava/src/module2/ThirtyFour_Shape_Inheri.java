package module2;

/*
 * Create a class named 'Shape' with a method to print "This is this is shape". Then
create two other classes named 'Rectangle', 'Circle' inheriting the Shape class, both
having a method to print "This is rectangular shape" and "This is circular shape"
respectively. Create a subclass 'Square' of 'Rectangle' having a method to print
"Square is a rectangle". Now call the method of 'Shape' and 'Rectangle' class by the
object of 'Square' class.
 */
class Shape1 {
	void print() {
		System.out.println("This is this is shape.");
	}
}

class Rectangle1 extends Shape1 {
	void print() {
		System.out.println("This is this is rectangular shape.");
	}
}

class Square1 extends Shape1 {
	void print() {
		System.out.println("Square is a rectangle");
	}
}

class Circle1 extends Shape1 {
	void print() {
		System.out.println("This is this is Circle shape.");
	}
}

public class ThirtyFour_Shape_Inheri {

	public static void main(String[] args) {
		Shape1 s = new Shape1();
		Rectangle1 r = new Rectangle1();
		Square1 s1 = new Square1();
		Circle1 c = new Circle1();

		s.print();
		r.print();
		s1.print();
		s1.print();
		c.print();
	}

}
