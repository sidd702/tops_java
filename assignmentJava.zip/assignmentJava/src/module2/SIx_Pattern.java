package module2;

import java.util.Scanner;

/*rite a program in Java to display the pattern like right angle triangle with a number.
1
12
123
1234
12345*/
public class SIx_Pattern {

	public static void main(String[] args) {
		int i, h, j;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter :");
		h = sc.nextInt();

		for (i = 1; i <= h; i++) {
			for (j = 1; j <= i; j++) {
				System.out.print(j);
			}
			System.out.println();
		}

	}

}
