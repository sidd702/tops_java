package module2;

import java.util.Scanner;

/*
 * Write a Java program that takes the user to provide a single character from the
alphabet. Print Vowel or Consonant, depending on the user input. If the user input
is not a letter (between a and z or A and Z), or is a string of length > 1, print an error
message
 */
public class TwoChkVowelConso {

	public static void main(String[] args) {
		char c;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter an alphabet");
		c = sc.next().charAt(0);

		if (c >= 'A' && c <= 'z') {
			if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' || c == 'a' || c == 'e' || c == 'i' || c == 'o'
					|| c == 'u') {
				System.out.println(c + " is an Vowel");
			} else {
				System.out.println(c + " is an Consonant");
			}
		} else {
			System.out.println("Not an Alphabet");
		}

	}

}
