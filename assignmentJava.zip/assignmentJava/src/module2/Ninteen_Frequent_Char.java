package module2;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/*W.A.J.P to find the second most frequent character in a given string. The given string
is: successes The second most frequent char in the string is: c*/
public class Ninteen_Frequent_Char {

	public static void main(String[] args) {
		String s1 = "aaabbcbbc";
		// String s1 = "abc";
		// String s1 = "abcc";
		char ch[] = s1.toCharArray();
		HashMap<Character, Integer> hm = new HashMap<Character, Integer>();

		for (char c : ch) {
			hm.putIfAbsent(c, 0);
			hm.replace(c, hm.get(c) + 1);
		}
		int max = 0, secondMax = 0;
		Iterator itr = hm.entrySet().iterator();

		while (itr.hasNext()) {
			Map.Entry mapEle = (Entry) itr.next();
			if ((int) mapEle.getValue() > max) {
				max = (int) mapEle.getValue();
			}
		}
		itr = hm.entrySet().iterator();
		while (itr.hasNext()) {
			Map.Entry mapEle = (Entry) itr.next();
			if ((int) mapEle.getValue() == max) {
				continue;
			} else if ((int) mapEle.getValue() > secondMax) {
				secondMax = (int) mapEle.getValue();
			}
		}

		// string abc
		if (secondMax == 0) {
			secondMax = max;
		}

		itr = hm.entrySet().iterator();
		while (itr.hasNext()) {
			Map.Entry mapEle = (Entry) itr.next();
			if ((int) mapEle.getValue() == secondMax) {
				System.out.println("Second Most Occurence is " + mapEle.getKey());
				break;
			}
		}

	}
}
