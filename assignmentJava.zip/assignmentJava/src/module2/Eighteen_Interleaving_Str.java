package module2;

/*W.A.J.P to find all interleaving of given strings.
The given strings are: WX YZ
The interleaving strings are: YWZX WYZX YWXZ WXYZ YZWX WYXZ*/
public class Eighteen_Interleaving_Str {

	public static void main(String[] args) {
		String s1 = "WX YZ";

		// PENDING
	}

}
