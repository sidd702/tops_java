package module2;

import java.util.Scanner;

//Write a Java program that takes a year from user and print whether that year is a leap
//year or not.
public class ThreeChkLeapYear {

	public static void main(String[] args) {
		int year;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter :");
		year = sc.nextInt();

		if (year % 4 == 0) {
			System.out.println("LEap");
		} else {
			System.out.println("Not LEap");
		}

	}

}
