package topsJava.BankException;

public class checkingAcct {
	int accNo;
	double bal;
	String name;

	public checkingAcct(int accNo, double amt, String name) {
		this.accNo = accNo;
		this.bal = amt;
		this.name = name;

		System.out.println(name + " NO " + accNo + " Bal " + amt);
	}

	void dep(double amt) {
		this.bal += amt;
	}

	void withdraw(double amt) throws InsuffBalException {
		if (amt > this.bal) {
			throw new InsuffBalException(amt - this.bal);
		} else {
			this.bal -= amt;
		}
	}

	void chkBal() {
		System.out.println("Bal " + this.bal);
	}

}
