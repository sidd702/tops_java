package module2;

/*
 * • W.A.J.P to create a class Student with attributes roll no, name, age and course.
Initialize values through parameterized constructor. If age of student is not in
between 15 and 21 then generate user defined exception
"AgeNotWithinRangeException". If name contains numbers or special symbols
raise exception "NameNotValidException". Define the two exception classes
 */
class NameNotValidException extends Exception {
	public NameNotValidException(char c) {
		System.out.println("Char " + c + " is not valid");
	}
}

class AgeNotWithinRangeException extends Exception {

	public AgeNotWithinRangeException(int a) {
		System.out.println("Age " + a + " is Not between 15 and 21");
	}
}

class Student {
	int age, roll;
	String name, course;

	public Student(int age, int roll, String n, String c) {
		this.age = age;
		this.roll = roll;
		this.name = n;
		this.course = c;
	}
}

public class Fourty_StudentException {

	public static void main(String[] args) throws AgeNotWithinRangeException, NameNotValidException {
		Student s1 = new Student(18, 1, "sid", "CE");

		if (s1.age >= 15 && s1.age <= 21) {
			System.out.println("Valid Name");
		} else {
			throw new AgeNotWithinRangeException(s1.age);
		}

		for (char c : s1.name.toCharArray()) {
			if (c >= 'A' && c <= 'z') {
				continue;
			} else {
				throw new NameNotValidException(c);
			}
		}

	}
}
