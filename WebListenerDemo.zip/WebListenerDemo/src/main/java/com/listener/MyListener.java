package com.listener;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;

public class MyListener implements ServletContextListener {

	public void contextInitialized(ServletContextEvent sce) {
		System.out.println("contextInitialized");
		sce.getServletContext().getAttribute("counter");
	}

	public void contextDestroyed(ServletContextEvent sce) {
		System.out.println("contextDestroyed");
		sce.getServletContext().getAttribute("counter");
	}

}
