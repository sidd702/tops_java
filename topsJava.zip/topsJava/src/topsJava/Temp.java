package topsJava;

public class Temp {

	public static void main(String[] args, int id) {
		System.out.println("Hello..");

		String cd = "form-data; name=\"prd_image\"; filename=\"car1.jpg\"";
		System.out.println(cd);// form-data; name="prd_image"; filename="car1.jpg";
		String[] items = cd.split(";");

		for (String item : items) {
			if (item.trim().startsWith("filename")) {
				String r = item.substring(item.indexOf("=") + 2, item.length() - 1);

				int lastDotIndex = r.lastIndexOf('.');
				String s = r.substring(0, lastDotIndex) + "V1" + r.substring(lastDotIndex);

				System.out.println("Car Img Name: " + s);
			}
		}
	}

}
